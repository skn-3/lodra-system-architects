// Loads a frame set into memory and draws frame N, cover-fitted, onto a 2D canvas.
// Preloads sparsely first (so scrubbing is responsive almost immediately), then fills in.
// If a given frame hasn't loaded yet, it draws the nearest one that has — no gaps.

import { framePath } from './heroConfig';

export function createSequence(set, { onProgress } = {}) {
  const frames = new Array(set.count).fill(null);
  let loaded = 0;
  let cancelled = false;

  function blobToImage(blob) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = URL.createObjectURL(blob);
    });
  }

  async function loadOne(i) {
    try {
      const res = await fetch(framePath(set, i));
      const blob = await res.blob();
      const bmp =
        typeof createImageBitmap === 'function'
          ? await createImageBitmap(blob)
          : await blobToImage(blob);
      if (!cancelled) frames[i] = bmp;
    } catch (e) {
      // leave null; draw() falls back to the nearest loaded frame
    } finally {
      loaded += 1;
      if (onProgress) onProgress(loaded / set.count);
    }
  }

  async function preload() {
    // Pass 1: every Nth frame, so the timeline is roughly drawable fast.
    const step = Math.max(1, Math.round(set.count / 24));
    const order = [];
    for (let i = 0; i < set.count; i += step) order.push(i);
    // Pass 2: everything else.
    for (let i = 0; i < set.count; i += 1) if (order.indexOf(i) === -1) order.push(i);
    for (const i of order) {
      if (cancelled) return;
      // eslint-disable-next-line no-await-in-loop
      await loadOne(i);
    }
  }

  function nearest(i) {
    if (frames[i]) return frames[i];
    for (let d = 1; d < set.count; d += 1) {
      if (i - d >= 0 && frames[i - d]) return frames[i - d];
      if (i + d < set.count && frames[i + d]) return frames[i + d];
    }
    return null;
  }

  function coverDraw(ctx, img) {
    const cw = ctx.canvas.width;
    const ch = ctx.canvas.height;
    const scale = Math.max(cw / img.width, ch / img.height);
    const w = img.width * scale;
    const h = img.height * scale;
    ctx.clearRect(0, 0, cw, ch);
    ctx.drawImage(img, (cw - w) / 2, (ch - h) / 2, w, h);
  }

  function draw(ctx, progress) {
    const i = Math.max(0, Math.min(set.count - 1, Math.round(progress * (set.count - 1))));
    const img = nearest(i);
    if (img) coverDraw(ctx, img);
  }

  function destroy() {
    cancelled = true;
  }

  return {
    preload,
    draw,
    destroy,
    get loaded() {
      return loaded;
    },
  };
}
