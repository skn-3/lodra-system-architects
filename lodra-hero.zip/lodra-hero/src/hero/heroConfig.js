// Lodra hero — frame-sequence config.
// The numbers here MUST match what scripts/extract-frames.sh produces.
// If you change fps/count in the script, change `count` here too.

export const HERO = {
  // How long the hero stays pinned, as a multiple of viewport height.
  // 300 = three screens of scroll drive the full animation. Higher = slower scrub.
  scrollLengthVh: 300,

  desktop: {
    dir: '/frames/desktop',
    prefix: 'frame_',
    ext: 'webp',
    count: 180, // 6s clip @ 30fps. Keep in sync with extract-frames.sh.
    pad: 4, // frame_0001.webp
    poster: '/frames/desktop/poster.webp', // shown before frames load + as low-power fallback
  },

  mobile: {
    dir: '/frames/mobile',
    prefix: 'frame_',
    ext: 'webp',
    count: 96, // 6s clip @ 16fps — lighter payload for phones.
    pad: 4,
    poster: '/frames/mobile/poster.webp',
  },

  // Below this width we use the portrait (9:16) set.
  mobileMaxWidth: 768,
};

export function framePath(set, i) {
  const n = String(i + 1).padStart(set.pad, '0');
  return `${set.dir}/${set.prefix}${n}.${set.ext}`;
}
