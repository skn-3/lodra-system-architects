// Smooth scroll (Lenis) synced to GSAP ScrollTrigger.
// Install once: npm i lenis gsap
// Call initSmoothScroll() once, near app start (e.g. in your root layout/App).

import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function initSmoothScroll() {
  if (typeof window === 'undefined') return null;

  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce) return null; // native scrolling for reduced-motion users

  const lenis = new Lenis({ lerp: 0.1, smoothWheel: true });
  lenis.on('scroll', ScrollTrigger.update);
  gsap.ticker.add((time) => lenis.raf(time * 1000));
  gsap.ticker.lagSmoothing(0);
  return lenis;
}
