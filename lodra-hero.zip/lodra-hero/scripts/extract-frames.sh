#!/usr/bin/env bash
# Lodra hero — extract scroll-scrub frames from the imagine.art clips.
#
# Prereq: ffmpeg installed.  macOS: brew install ffmpeg   •   Windows: https://www.gyan.dev/ffmpeg/builds/
#
# Usage:
#   ./extract-frames.sh path/to/landscape.mp4 path/to/portrait.mp4
#
# Output:
#   public/frames/desktop/frame_0001.webp ... + poster.webp   (180 frames @ 30fps from the 6s landscape clip)
#   public/frames/mobile/frame_0001.webp  ... + poster.webp   ( 96 frames @ 16fps from the 6s portrait  clip)
#
# Keep the frame COUNTS in sync with src/hero/heroConfig.js (desktop.count / mobile.count).

set -euo pipefail

LANDSCAPE="${1:?Pass the landscape clip as arg 1}"
PORTRAIT="${2:?Pass the portrait clip as arg 2}"

DESK_DIR="public/frames/desktop"
MOB_DIR="public/frames/mobile"
mkdir -p "$DESK_DIR" "$MOB_DIR"

echo "→ Desktop frames (1600px wide, 30fps, webp q80)"
ffmpeg -y -i "$LANDSCAPE" -vf "fps=30,scale=1600:-2" -c:v libwebp -q:v 80 "$DESK_DIR/frame_%04d.webp"
# poster = last frame (fully assembled)
cp "$(ls "$DESK_DIR"/frame_*.webp | tail -n 1)" "$DESK_DIR/poster.webp"

echo "→ Mobile frames (828px wide, 16fps, webp q78)"
ffmpeg -y -i "$PORTRAIT" -vf "fps=16,scale=828:-2" -c:v libwebp -q:v 78 "$MOB_DIR/frame_%04d.webp"
cp "$(ls "$MOB_DIR"/frame_*.webp | tail -n 1)" "$MOB_DIR/poster.webp"

echo
echo "Done. Frame counts:"
echo "  desktop: $(ls "$DESK_DIR"/frame_*.webp | wc -l | tr -d ' ')   (set HERO.desktop.count to this)"
echo "  mobile : $(ls "$MOB_DIR"/frame_*.webp  | wc -l | tr -d ' ')   (set HERO.mobile.count to this)"
echo
echo "Tip: keep each folder's total weight reasonable (aim < ~2 MB for mobile)."
echo "If it's heavy, lower the scale width or the q value above and re-run."
